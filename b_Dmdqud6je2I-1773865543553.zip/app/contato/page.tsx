"use client"

import { useState } from "react"
import { MapPin, Phone, Mail, Send, CheckCircle } from "lucide-react"
import { Header } from "@/components/site/header"
import { Footer } from "@/components/site/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { FieldGroup, Field, FieldLabel } from "@/components/ui/field"

export default function ContatoPage() {
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24">
        {/* Hero */}
        <section className="bg-card border-b border-border">
          <div className="mx-auto max-w-7xl px-6 py-16 lg:px-8">
            <div className="max-w-2xl">
              <p className="text-sm font-medium uppercase tracking-widest text-primary mb-3">
                Contato
              </p>
              <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl text-balance">
                Fale conosco
              </h1>
              <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
                Tem alguma dúvida, sugestão ou quer propor uma parceria? Estamos prontos para ouvir você.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-20">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
              {/* Contact Info */}
              <div>
                <h2 className="text-2xl font-bold text-foreground">
                  Entre em contato
                </h2>
                <p className="mt-4 text-muted-foreground leading-relaxed">
                  Seja para parcerias, dúvidas sobre nossos projetos ou para participar da nossa equipe, ficaremos felizes em conversar com você.
                </p>

                <div className="mt-10 space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                      <MapPin className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-medium text-foreground">Endereço</h3>
                      <p className="mt-1 text-sm text-muted-foreground">
                        Campus Universitário, Bloco A<br />
                        Departamento de Agronomia<br />
                        São Paulo, SP - Brasil
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                      <Phone className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-medium text-foreground">Telefone</h3>
                      <p className="mt-1 text-sm text-muted-foreground">
                        (11) 1234-5678
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                      <Mail className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-medium text-foreground">Email</h3>
                      <p className="mt-1 text-sm text-muted-foreground">
                        contato@citahub.com.br
                      </p>
                    </div>
                  </div>
                </div>

                {/* Hours */}
                <div className="mt-10 p-6 rounded-xl bg-muted/50 border border-border">
                  <h3 className="font-medium text-foreground">Horário de Atendimento</h3>
                  <div className="mt-3 space-y-2 text-sm text-muted-foreground">
                    <div className="flex justify-between">
                      <span>Segunda a Sexta</span>
                      <span className="font-medium text-foreground">08:00 - 18:00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Sábado</span>
                      <span className="font-medium text-foreground">08:00 - 12:00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Domingo</span>
                      <span>Fechado</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact Form */}
              <div className="bg-card rounded-2xl border border-border p-8">
                {submitted ? (
                  <div className="flex flex-col items-center justify-center h-full text-center py-12">
                    <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary mb-6">
                      <CheckCircle className="h-8 w-8" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground">
                      Mensagem enviada!
                    </h3>
                    <p className="mt-2 text-muted-foreground max-w-sm">
                      Obrigado pelo contato. Responderemos sua mensagem em até 48 horas úteis.
                    </p>
                    <Button
                      className="mt-6"
                      variant="outline"
                      onClick={() => setSubmitted(false)}
                    >
                      Enviar nova mensagem
                    </Button>
                  </div>
                ) : (
                  <>
                    <h2 className="text-xl font-semibold text-foreground">
                      Envie sua mensagem
                    </h2>
                    <p className="mt-2 text-sm text-muted-foreground">
                      Preencha o formulário abaixo e entraremos em contato.
                    </p>

                    <form onSubmit={handleSubmit} className="mt-8">
                      <FieldGroup>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <Field>
                            <FieldLabel>Nome</FieldLabel>
                            <Input placeholder="Seu nome completo" required />
                          </Field>
                          <Field>
                            <FieldLabel>Email</FieldLabel>
                            <Input type="email" placeholder="seu@email.com" required />
                          </Field>
                        </div>

                        <Field>
                          <FieldLabel>Assunto</FieldLabel>
                          <Input placeholder="Sobre o que você gostaria de falar?" required />
                        </Field>

                        <Field>
                          <FieldLabel>Mensagem</FieldLabel>
                          <Textarea
                            placeholder="Escreva sua mensagem aqui..."
                            className="min-h-[150px] resize-none"
                            required
                          />
                        </Field>

                        <Button type="submit" className="w-full gap-2">
                          <Send className="h-4 w-4" />
                          Enviar Mensagem
                        </Button>
                      </FieldGroup>
                    </form>
                  </>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
