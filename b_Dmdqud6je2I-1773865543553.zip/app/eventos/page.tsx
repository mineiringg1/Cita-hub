import Image from "next/image"
import Link from "next/link"
import { Calendar, MapPin, Clock, Users, ArrowRight, ExternalLink } from "lucide-react"
import { Header } from "@/components/site/header"
import { Footer } from "@/components/site/footer"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

const upcomingEvents = [
  {
    id: 1,
    title: "Workshop: Introdução à Agricultura de Precisão",
    description: "Aprenda os fundamentos da agricultura de precisão e como aplicar tecnologias como drones e sensores IoT na sua propriedade.",
    date: "25 de Março de 2026",
    time: "14:00 - 18:00",
    location: "Auditório do Bloco A - Campus Agronomia",
    image: "/images/technology.jpg",
    type: "Workshop",
    spots: 50,
    spotsLeft: 12,
  },
  {
    id: 2,
    title: "Palestra: Sustentabilidade e Certificações Verdes",
    description: "Especialistas discutem as principais certificações ambientais e como implementar práticas sustentáveis no agronegócio.",
    date: "02 de Abril de 2026",
    time: "19:00 - 21:00",
    location: "Online - Transmissão ao vivo",
    image: "/images/sustainability.jpg",
    type: "Palestra",
    spots: 200,
    spotsLeft: 87,
  },
  {
    id: 3,
    title: "Visita Técnica: Fazenda Modelo em Agricultura Sustentável",
    description: "Visita guiada a uma propriedade referência em práticas sustentáveis e integração lavoura-pecuária-floresta.",
    date: "15 de Abril de 2026",
    time: "08:00 - 17:00",
    location: "Fazenda São João - Piracicaba/SP",
    image: "/images/innovation.jpg",
    type: "Visita Técnica",
    spots: 30,
    spotsLeft: 8,
  },
]

const pastEvents = [
  {
    id: 4,
    title: "Seminário: O Futuro do Agronegócio Brasileiro",
    date: "10 de Março de 2026",
    image: "/images/event.jpg",
    type: "Seminário",
    attendees: 150,
  },
  {
    id: 5,
    title: "Workshop: Gestão Financeira para Produtores Rurais",
    date: "28 de Fevereiro de 2026",
    image: "/images/research.jpg",
    type: "Workshop",
    attendees: 45,
  },
  {
    id: 6,
    title: "Palestra: Tendências em Biotecnologia Agrícola",
    date: "15 de Fevereiro de 2026",
    image: "/images/technology.jpg",
    type: "Palestra",
    attendees: 120,
  },
]

const eventTypeColors: Record<string, string> = {
  Workshop: "bg-blue-500/10 text-blue-700 border-blue-200",
  Palestra: "bg-primary/10 text-primary border-primary/20",
  "Visita Técnica": "bg-accent/10 text-accent border-accent/20",
  Seminário: "bg-purple-500/10 text-purple-700 border-purple-200",
}

export default function EventosPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24">
        {/* Hero */}
        <section className="bg-card border-b border-border">
          <div className="mx-auto max-w-7xl px-6 py-16 lg:px-8">
            <div className="max-w-2xl">
              <p className="text-sm font-medium uppercase tracking-widest text-primary mb-3">
                Eventos
              </p>
              <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl text-balance">
                Participe dos nossos eventos
              </h1>
              <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
                Workshops, palestras, visitas técnicas e muito mais. Conecte-se com especialistas e aprenda sobre as últimas tendências do agronegócio.
              </p>
            </div>
          </div>
        </section>

        {/* Upcoming Events */}
        <section className="py-16">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <h2 className="text-2xl font-bold text-foreground mb-8">
              Próximos Eventos
            </h2>

            <div className="space-y-6">
              {upcomingEvents.map((event) => (
                <div
                  key={event.id}
                  className="group flex flex-col lg:flex-row gap-6 bg-card rounded-2xl border border-border overflow-hidden hover:border-primary/30 hover:shadow-lg transition-all"
                >
                  {/* Image */}
                  <div className="relative lg:w-80 h-48 lg:h-auto shrink-0">
                    <Image
                      src={event.image}
                      alt={event.title}
                      fill
                      className="object-cover"
                    />
                    <div className="absolute top-4 left-4">
                      <Badge className={eventTypeColors[event.type]}>
                        {event.type}
                      </Badge>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex flex-col flex-1 p-6 lg:py-8">
                    <h3 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors text-balance">
                      {event.title}
                    </h3>
                    <p className="mt-2 text-muted-foreground line-clamp-2">
                      {event.description}
                    </p>

                    {/* Details */}
                    <div className="mt-4 flex flex-wrap gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1.5">
                        <Calendar className="h-4 w-4 text-primary" />
                        {event.date}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Clock className="h-4 w-4 text-primary" />
                        {event.time}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <MapPin className="h-4 w-4 text-primary" />
                        {event.location}
                      </span>
                    </div>

                    {/* Footer */}
                    <div className="mt-auto pt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-center gap-2 text-sm">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">
                          <span className="font-medium text-foreground">{event.spotsLeft}</span> vagas restantes de {event.spots}
                        </span>
                      </div>
                      <Button className="gap-2">
                        Inscrever-se
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Past Events */}
        <section className="py-16 bg-muted/30">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-foreground">
                Eventos Anteriores
              </h2>
              <Button variant="outline" size="sm" className="gap-2">
                Ver arquivo completo
                <ExternalLink className="h-3 w-3" />
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {pastEvents.map((event) => (
                <div
                  key={event.id}
                  className="group bg-card rounded-xl border border-border overflow-hidden hover:border-primary/30 transition-all"
                >
                  <div className="relative h-40">
                    <Image
                      src={event.image}
                      alt={event.title}
                      fill
                      className="object-cover grayscale group-hover:grayscale-0 transition-all duration-300"
                    />
                    <div className="absolute inset-0 bg-foreground/20 group-hover:bg-transparent transition-colors" />
                    <div className="absolute top-3 left-3">
                      <Badge className={`${eventTypeColors[event.type]} text-xs`}>
                        {event.type}
                      </Badge>
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="font-medium text-foreground line-clamp-2 text-balance">
                      {event.title}
                    </h3>
                    <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {event.date}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="h-3 w-3" />
                        {event.attendees} participantes
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-sidebar">
          <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
            <h2 className="text-2xl font-bold text-sidebar-foreground sm:text-3xl text-balance">
              Quer organizar um evento conosco?
            </h2>
            <p className="mt-4 text-sidebar-accent-foreground/80 max-w-xl mx-auto">
              Temos interesse em parcerias para workshops, palestras e outras iniciativas que promovam a inovação no agronegócio.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link href="/contato">Propor Parceria</Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-transparent border-sidebar-accent-foreground/30 text-sidebar-foreground hover:bg-sidebar-accent"
                asChild
              >
                <Link href="/boletins">Ver Boletins</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
