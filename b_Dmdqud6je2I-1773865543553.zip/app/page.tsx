import { Header } from "@/components/site/header"
import { Footer } from "@/components/site/footer"
import { HeroSection } from "@/components/site/hero-section"
import { AboutSection } from "@/components/site/about-section"
import { FeaturedNewsSection } from "@/components/site/featured-news-section"
import { CTASection } from "@/components/site/cta-section"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <AboutSection />
        <FeaturedNewsSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  )
}
