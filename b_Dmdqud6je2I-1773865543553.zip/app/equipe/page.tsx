import Image from "next/image"
import Link from "next/link"
import { Linkedin, Mail, GraduationCap, Target, Users, Lightbulb } from "lucide-react"
import { Header } from "@/components/site/header"
import { Footer } from "@/components/site/footer"

const teamMembers = [
  {
    id: 1,
    name: "Ana Clara Mendes",
    role: "Coordenadora Geral",
    course: "Agronomia - 8º semestre",
    bio: "Apaixonada por agricultura de precisão e tecnologias sustentáveis.",
    avatar: "/avatars/team-1.jpg",
    linkedin: "#",
    email: "ana.mendes@citahub.com.br",
  },
  {
    id: 2,
    name: "Pedro Henrique Oliveira",
    role: "Diretor de Pesquisa",
    course: "Agronomia - 7º semestre",
    bio: "Focado em desenvolvimento de cultivares resistentes e sustentabilidade.",
    avatar: "/avatars/team-2.jpg",
    linkedin: "#",
    email: "pedro.oliveira@citahub.com.br",
  },
  {
    id: 3,
    name: "Juliana Costa Santos",
    role: "Editora de Conteúdo",
    course: "Agronegócio - 6º semestre",
    bio: "Especialista em comunicação rural e marketing agrícola.",
    avatar: "/avatars/team-3.jpg",
    linkedin: "#",
    email: "juliana.costa@citahub.com.br",
  },
  {
    id: 4,
    name: "Lucas Fernandes Silva",
    role: "Coordenador de Eventos",
    course: "Agronegócio - 5º semestre",
    bio: "Organizador de eventos e workshops sobre inovação no campo.",
    avatar: "/avatars/team-4.jpg",
    linkedin: "#",
    email: "lucas.fernandes@citahub.com.br",
  },
  {
    id: 5,
    name: "Mariana Rodrigues Lima",
    role: "Pesquisadora",
    course: "Agronomia - 6º semestre",
    bio: "Estuda sistemas agroflorestais e integração lavoura-pecuária.",
    avatar: "/avatars/team-5.jpg",
    linkedin: "#",
    email: "mariana.lima@citahub.com.br",
  },
  {
    id: 6,
    name: "Rafael Almeida Costa",
    role: "Desenvolvedor de Projetos",
    course: "Agronegócio - 7º semestre",
    bio: "Trabalha com gestão de projetos e captação de parcerias.",
    avatar: "/avatars/team-6.jpg",
    linkedin: "#",
    email: "rafael.costa@citahub.com.br",
  },
]

const values = [
  {
    icon: Lightbulb,
    title: "Inovação",
    description: "Buscamos constantemente novas soluções e tecnologias para os desafios do agronegócio.",
  },
  {
    icon: Target,
    title: "Compromisso",
    description: "Dedicação total à qualidade do nosso trabalho e ao impacto positivo na comunidade.",
  },
  {
    icon: Users,
    title: "Colaboração",
    description: "Acreditamos no poder do trabalho em equipe e das parcerias estratégicas.",
  },
]

export default function EquipePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24">
        {/* Hero */}
        <section className="bg-card border-b border-border">
          <div className="mx-auto max-w-7xl px-6 py-20 lg:px-8 text-center">
            <p className="text-sm font-medium uppercase tracking-widest text-primary mb-3">
              Nossa Equipe
            </p>
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl text-balance">
              Quem faz o CITA acontecer
            </h1>
            <p className="mt-6 text-lg text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              Somos estudantes de Agronomia e Agronegócio unidos pela paixão em transformar o campo brasileiro através da inovação, pesquisa e tecnologia.
            </p>
          </div>
        </section>

        {/* Values */}
        <section className="py-16 bg-muted/30">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {values.map((value) => (
                <div
                  key={value.title}
                  className="flex flex-col items-center text-center p-6"
                >
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                    <value.icon className="h-7 w-7" />
                  </div>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">
                    {value.title}
                  </h3>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                    {value.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Team Grid */}
        <section className="py-20">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {teamMembers.map((member) => (
                <div
                  key={member.id}
                  className="group bg-card rounded-2xl border border-border p-8 text-center hover:border-primary/30 hover:shadow-lg transition-all"
                >
                  {/* Avatar */}
                  <div className="relative mx-auto w-28 h-28 rounded-full overflow-hidden border-4 border-primary/20 group-hover:border-primary/40 transition-colors">
                    <Image
                      src={member.avatar}
                      alt={member.name}
                      fill
                      className="object-cover"
                    />
                  </div>

                  {/* Info */}
                  <h3 className="mt-6 text-lg font-semibold text-foreground">
                    {member.name}
                  </h3>
                  <p className="text-sm font-medium text-primary mt-1">
                    {member.role}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1 flex items-center justify-center gap-1">
                    <GraduationCap className="h-3 w-3" />
                    {member.course}
                  </p>
                  <p className="mt-4 text-sm text-muted-foreground leading-relaxed">
                    {member.bio}
                  </p>

                  {/* Social Links */}
                  <div className="mt-6 flex justify-center gap-3">
                    <Link
                      href={member.linkedin}
                      className="flex h-9 w-9 items-center justify-center rounded-full bg-muted text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
                    >
                      <Linkedin className="h-4 w-4" />
                      <span className="sr-only">LinkedIn de {member.name}</span>
                    </Link>
                    <Link
                      href={`mailto:${member.email}`}
                      className="flex h-9 w-9 items-center justify-center rounded-full bg-muted text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
                    >
                      <Mail className="h-4 w-4" />
                      <span className="sr-only">Email de {member.name}</span>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-primary/5 border-t border-border">
          <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
            <h2 className="text-2xl font-bold text-foreground sm:text-3xl">
              Quer fazer parte da nossa equipe?
            </h2>
            <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
              Estamos sempre em busca de estudantes apaixonados por inovação no agronegócio. Entre em contato conosco!
            </p>
            <Link
              href="/contato"
              className="mt-8 inline-flex items-center justify-center rounded-lg bg-primary px-6 py-3 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors"
            >
              Fale Conosco
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
