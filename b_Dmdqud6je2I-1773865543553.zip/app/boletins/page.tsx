import Image from "next/image"
import Link from "next/link"
import { Calendar, User, ArrowRight, Search } from "lucide-react"
import { Header } from "@/components/site/header"
import { Footer } from "@/components/site/footer"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const categories = [
  { name: "Todos", slug: "todos", count: 24 },
  { name: "Tecnologia", slug: "tecnologia", count: 8 },
  { name: "Sustentabilidade", slug: "sustentabilidade", count: 7 },
  { name: "Pesquisa", slug: "pesquisa", count: 5 },
  { name: "Inovação", slug: "inovacao", count: 4 },
]

const articles = [
  {
    id: 1,
    slug: "agricultura-de-precisao-revolucionando-o-campo",
    title: "Agricultura de Precisão: Como a tecnologia está revolucionando o campo brasileiro",
    excerpt: "Descubra como drones, sensores IoT e inteligência artificial estão transformando a forma como produzimos alimentos e aumentando a eficiência no agronegócio.",
    image: "/images/technology.jpg",
    category: "Tecnologia",
    author: "Ana Clara Mendes",
    date: "15 Mar 2026",
  },
  {
    id: 2,
    slug: "praticas-sustentaveis-certificacoes-verdes",
    title: "Práticas Sustentáveis e Certificações Verdes no Agronegócio",
    excerpt: "Um guia completo sobre como implementar práticas sustentáveis na sua propriedade e obter certificações ambientais reconhecidas internacionalmente.",
    image: "/images/sustainability.jpg",
    category: "Sustentabilidade",
    author: "Pedro Oliveira",
    date: "12 Mar 2026",
  },
  {
    id: 3,
    slug: "pesquisa-variedades-resistentes-seca",
    title: "Nova Pesquisa: Variedades Resistentes à Seca",
    excerpt: "Estudo desenvolvido em parceria com a Embrapa revela novas variedades de milho e soja com maior resistência ao estresse hídrico.",
    image: "/images/research.jpg",
    category: "Pesquisa",
    author: "Juliana Costa",
    date: "10 Mar 2026",
  },
  {
    id: 4,
    slug: "inovacao-irrigacao-inteligente",
    title: "Inovação em Irrigação Inteligente: Economia de Água",
    excerpt: "Sistemas modernos de irrigação podem reduzir o consumo de água em até 40% mantendo a produtividade das lavouras.",
    image: "/images/innovation.jpg",
    category: "Inovação",
    author: "Lucas Fernandes",
    date: "08 Mar 2026",
  },
  {
    id: 5,
    slug: "blockchain-rastreabilidade-alimentos",
    title: "Blockchain na Rastreabilidade de Alimentos",
    excerpt: "Como a tecnologia blockchain está garantindo a procedência e qualidade dos alimentos do campo à mesa do consumidor.",
    image: "/images/technology.jpg",
    category: "Tecnologia",
    author: "Mariana Santos",
    date: "05 Mar 2026",
  },
  {
    id: 6,
    slug: "agrofloresta-modelo-producao-sustentavel",
    title: "Agrofloresta: Um Modelo de Produção Sustentável",
    excerpt: "Conheça os benefícios da integração entre agricultura e floresta para uma produção mais sustentável e diversificada.",
    image: "/images/sustainability.jpg",
    category: "Sustentabilidade",
    author: "Rafael Lima",
    date: "01 Mar 2026",
  },
]

const categoryColors: Record<string, string> = {
  Tecnologia: "bg-blue-500/10 text-blue-700 border-blue-200",
  Sustentabilidade: "bg-primary/10 text-primary border-primary/20",
  Pesquisa: "bg-accent/10 text-accent border-accent/20",
  Inovação: "bg-purple-500/10 text-purple-700 border-purple-200",
}

export default function BoletinsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24">
        {/* Hero */}
        <section className="bg-card border-b border-border">
          <div className="mx-auto max-w-7xl px-6 py-16 lg:px-8">
            <div className="max-w-2xl">
              <p className="text-sm font-medium uppercase tracking-widest text-primary mb-3">
                Boletins Informativos
              </p>
              <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl text-balance">
                Fique por dentro das novidades do agronegócio
              </h1>
              <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
                Artigos, pesquisas e análises sobre inovação, tecnologia e sustentabilidade no campo.
              </p>
            </div>

            {/* Search */}
            <div className="mt-8 flex gap-4 max-w-xl">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar artigos..."
                  className="pl-10"
                />
              </div>
              <Button>Buscar</Button>
            </div>
          </div>
        </section>

        {/* Content */}
        <section className="py-12">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row gap-12">
              {/* Sidebar */}
              <aside className="lg:w-64 shrink-0">
                <h2 className="text-sm font-semibold text-foreground mb-4">Categorias</h2>
                <nav className="space-y-1">
                  {categories.map((category) => (
                    <Link
                      key={category.slug}
                      href={`/boletins?categoria=${category.slug}`}
                      className="flex items-center justify-between px-3 py-2 text-sm rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
                    >
                      <span>{category.name}</span>
                      <span className="text-xs bg-muted px-2 py-0.5 rounded-full">
                        {category.count}
                      </span>
                    </Link>
                  ))}
                </nav>
              </aside>

              {/* Articles Grid */}
              <div className="flex-1">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {articles.map((article) => (
                    <Link
                      key={article.id}
                      href={`/boletins/${article.slug}`}
                      className="group flex flex-col bg-card rounded-2xl border border-border overflow-hidden hover:border-primary/30 hover:shadow-lg transition-all"
                    >
                      <div className="relative h-48 overflow-hidden">
                        <Image
                          src={article.image}
                          alt={article.title}
                          fill
                          className="object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                        <div className="absolute top-4 left-4">
                          <Badge className={categoryColors[article.category]}>
                            {article.category}
                          </Badge>
                        </div>
                      </div>

                      <div className="flex flex-col flex-1 p-6">
                        <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-2 text-balance">
                          {article.title}
                        </h3>
                        <p className="mt-2 text-sm text-muted-foreground line-clamp-3 flex-1">
                          {article.excerpt}
                        </p>

                        <div className="mt-4 pt-4 border-t border-border flex items-center justify-between">
                          <div className="flex items-center gap-3 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <User className="h-3 w-3" />
                              {article.author}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {article.date}
                            </span>
                          </div>
                          <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>

                {/* Pagination */}
                <div className="mt-12 flex justify-center gap-2">
                  <Button variant="outline" disabled>
                    Anterior
                  </Button>
                  <Button variant="outline" className="bg-primary text-primary-foreground hover:bg-primary/90">
                    1
                  </Button>
                  <Button variant="outline">2</Button>
                  <Button variant="outline">3</Button>
                  <Button variant="outline">
                    Próximo
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
