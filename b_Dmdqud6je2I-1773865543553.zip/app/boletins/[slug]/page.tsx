import Image from "next/image"
import Link from "next/link"
import { Calendar, User, ArrowLeft, Share2, Linkedin, Twitter, Facebook, Clock } from "lucide-react"
import { Header } from "@/components/site/header"
import { Footer } from "@/components/site/footer"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

// Mock data - in production, this would come from a CMS or database
const article = {
  slug: "agricultura-de-precisao-revolucionando-o-campo",
  title: "Agricultura de Precisão: Como a tecnologia está revolucionando o campo brasileiro",
  excerpt: "Descubra como drones, sensores IoT e inteligência artificial estão transformando a forma como produzimos alimentos e aumentando a eficiência no agronegócio.",
  image: "/images/technology.jpg",
  category: "Tecnologia",
  author: {
    name: "Ana Clara Mendes",
    role: "Pesquisadora em Tecnologia Agrícola",
    avatar: "/avatars/avatar-1.jpg",
  },
  date: "15 de Março de 2026",
  readTime: "8 min de leitura",
  content: `
    <p>A agricultura de precisão representa uma das maiores revoluções no campo brasileiro nas últimas décadas. Com o uso de tecnologias avançadas como drones, sensores IoT e inteligência artificial, os produtores rurais conseguem otimizar seus processos, reduzir custos e aumentar a produtividade de forma sustentável.</p>

    <h2>O que é Agricultura de Precisão?</h2>
    <p>A agricultura de precisão é um sistema de gerenciamento agrícola baseado na variabilidade espacial e temporal da lavoura. Ela utiliza tecnologias de informação para coletar dados detalhados sobre as condições do solo, clima e plantas, permitindo uma tomada de decisão mais assertiva.</p>

    <p>Entre as principais tecnologias utilizadas, destacam-se:</p>
    <ul>
      <li><strong>Drones e VANTs:</strong> Utilizados para mapeamento aéreo, monitoramento de pragas e aplicação localizada de defensivos.</li>
      <li><strong>Sensores IoT:</strong> Dispositivos instalados no campo que coletam dados em tempo real sobre umidade do solo, temperatura e outros parâmetros.</li>
      <li><strong>GPS e sistemas de orientação:</strong> Permitem a aplicação precisa de insumos, evitando desperdícios e sobreposições.</li>
      <li><strong>Inteligência Artificial:</strong> Algoritmos que processam grandes volumes de dados para gerar insights e previsões.</li>
    </ul>

    <h2>Benefícios para o Produtor</h2>
    <p>A adoção da agricultura de precisão traz diversos benefícios tangíveis para os produtores rurais brasileiros:</p>

    <p><strong>Redução de custos:</strong> A aplicação localizada de insumos pode reduzir o consumo de fertilizantes em até 30% e de defensivos em até 40%, representando uma economia significativa nos custos de produção.</p>

    <p><strong>Aumento da produtividade:</strong> Com o manejo correto baseado em dados precisos, é possível aumentar a produtividade em até 20%, dependendo da cultura e das condições locais.</p>

    <p><strong>Sustentabilidade ambiental:</strong> A redução no uso de insumos e a aplicação mais eficiente contribuem para a preservação do meio ambiente e dos recursos naturais.</p>

    <h2>Desafios e Perspectivas</h2>
    <p>Apesar dos benefícios, a adoção da agricultura de precisão ainda enfrenta alguns desafios no Brasil. O custo inicial de implementação, a necessidade de capacitação técnica e a conectividade em áreas rurais são barreiras que precisam ser superadas.</p>

    <p>No entanto, o cenário é promissor. Com o avanço da tecnologia e a redução dos custos dos equipamentos, a tendência é que a agricultura de precisão se torne cada vez mais acessível para produtores de todos os portes.</p>

    <h2>Conclusão</h2>
    <p>A agricultura de precisão não é mais uma tendência futura, mas uma realidade presente no campo brasileiro. Os produtores que investirem nessas tecnologias estarão melhor preparados para os desafios do agronegócio moderno, aumentando sua competitividade e contribuindo para um setor mais sustentável.</p>
  `,
}

const relatedArticles = [
  {
    id: 2,
    slug: "praticas-sustentaveis-certificacoes-verdes",
    title: "Práticas Sustentáveis e Certificações Verdes",
    image: "/images/sustainability.jpg",
    category: "Sustentabilidade",
  },
  {
    id: 3,
    slug: "pesquisa-variedades-resistentes-seca",
    title: "Nova Pesquisa: Variedades Resistentes à Seca",
    image: "/images/research.jpg",
    category: "Pesquisa",
  },
  {
    id: 4,
    slug: "inovacao-irrigacao-inteligente",
    title: "Inovação em Irrigação Inteligente",
    image: "/images/innovation.jpg",
    category: "Inovação",
  },
]

const categoryColors: Record<string, string> = {
  Tecnologia: "bg-blue-500/10 text-blue-700 border-blue-200",
  Sustentabilidade: "bg-primary/10 text-primary border-primary/20",
  Pesquisa: "bg-accent/10 text-accent border-accent/20",
  Inovação: "bg-purple-500/10 text-purple-700 border-purple-200",
}

export default function ArticlePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24">
        {/* Hero Image */}
        <div className="relative h-[50vh] min-h-[400px]">
          <Image
            src={article.image}
            alt={article.title}
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
        </div>

        {/* Content */}
        <div className="relative -mt-32 z-10">
          <div className="mx-auto max-w-4xl px-6 lg:px-8">
            {/* Article Header */}
            <div className="bg-card rounded-2xl border border-border p-8 shadow-lg">
              <Link
                href="/boletins"
                className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-6"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar para Boletins
              </Link>

              <Badge className={categoryColors[article.category]}>
                {article.category}
              </Badge>

              <h1 className="mt-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl text-balance leading-tight">
                {article.title}
              </h1>

              <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
                {article.excerpt}
              </p>

              {/* Author & Meta */}
              <div className="mt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-6 border-t border-border">
                <div className="flex items-center gap-4">
                  <Image
                    src={article.author.avatar}
                    alt={article.author.name}
                    width={48}
                    height={48}
                    className="rounded-full object-cover"
                  />
                  <div>
                    <p className="font-medium text-foreground">{article.author.name}</p>
                    <p className="text-sm text-muted-foreground">{article.author.role}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    {article.date}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {article.readTime}
                  </span>
                </div>
              </div>
            </div>

            {/* Article Body */}
            <article
              className="mt-12 prose prose-lg prose-gray max-w-none
                prose-headings:text-foreground prose-headings:font-semibold
                prose-p:text-muted-foreground prose-p:leading-relaxed
                prose-strong:text-foreground
                prose-ul:text-muted-foreground
                prose-li:marker:text-primary"
              dangerouslySetInnerHTML={{ __html: article.content }}
            />

            {/* Share */}
            <div className="mt-12 pt-8 border-t border-border">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <p className="text-sm font-medium text-foreground flex items-center gap-2">
                  <Share2 className="h-4 w-4" />
                  Compartilhe este artigo
                </p>
                <div className="flex gap-2">
                  <Button variant="outline" size="icon">
                    <Linkedin className="h-4 w-4" />
                    <span className="sr-only">LinkedIn</span>
                  </Button>
                  <Button variant="outline" size="icon">
                    <Twitter className="h-4 w-4" />
                    <span className="sr-only">Twitter</span>
                  </Button>
                  <Button variant="outline" size="icon">
                    <Facebook className="h-4 w-4" />
                    <span className="sr-only">Facebook</span>
                  </Button>
                </div>
              </div>
            </div>

            {/* Related Articles */}
            <div className="mt-16 mb-24">
              <h2 className="text-2xl font-bold text-foreground mb-8">
                Artigos Relacionados
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                {relatedArticles.map((related) => (
                  <Link
                    key={related.id}
                    href={`/boletins/${related.slug}`}
                    className="group"
                  >
                    <div className="relative h-40 rounded-xl overflow-hidden mb-4">
                      <Image
                        src={related.image}
                        alt={related.title}
                        fill
                        className="object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                      <div className="absolute top-3 left-3">
                        <Badge className={`${categoryColors[related.category]} text-xs`}>
                          {related.category}
                        </Badge>
                      </div>
                    </div>
                    <h3 className="font-medium text-foreground group-hover:text-primary transition-colors line-clamp-2 text-balance">
                      {related.title}
                    </h3>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
