import Link from "next/link"
import { Leaf, Instagram, Linkedin, Mail, MapPin, Phone } from "lucide-react"

const navigation = {
  main: [
    { name: "Início", href: "/" },
    { name: "Boletins", href: "/boletins" },
    { name: "Eventos", href: "/eventos" },
    { name: "Equipe", href: "/equipe" },
  ],
  resources: [
    { name: "Publicações", href: "/boletins" },
    { name: "Pesquisas", href: "/boletins?categoria=pesquisa" },
    { name: "Agenda", href: "/eventos" },
  ],
  social: [
    { name: "Instagram", href: "#", icon: Instagram },
    { name: "LinkedIn", href: "#", icon: Linkedin },
    { name: "Email", href: "mailto:contato@citahub.com.br", icon: Mail },
  ],
}

export function Footer() {
  return (
    <footer className="bg-sidebar text-sidebar-foreground">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-sidebar-primary">
                <Leaf className="h-5 w-5 text-sidebar-primary-foreground" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold leading-tight">CITA Hub</span>
                <span className="text-[10px] text-sidebar-accent-foreground/70 leading-tight">
                  Centro de Inovação e Tecnologia Agrícola
                </span>
              </div>
            </Link>
            <p className="mt-4 text-sm text-sidebar-accent-foreground/80 leading-relaxed">
              Promovendo a inovação e sustentabilidade no agronegócio brasileiro através de pesquisa, educação e tecnologia.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="text-sm font-semibold">Navegação</h3>
            <ul className="mt-4 space-y-3">
              {navigation.main.map((item) => (
                <li key={item.name}>
                  <Link
                    href={item.href}
                    className="text-sm text-sidebar-accent-foreground/70 transition-colors hover:text-sidebar-foreground"
                  >
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="text-sm font-semibold">Recursos</h3>
            <ul className="mt-4 space-y-3">
              {navigation.resources.map((item) => (
                <li key={item.name}>
                  <Link
                    href={item.href}
                    className="text-sm text-sidebar-accent-foreground/70 transition-colors hover:text-sidebar-foreground"
                  >
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-sm font-semibold">Contato</h3>
            <ul className="mt-4 space-y-3">
              <li className="flex items-start gap-2 text-sm text-sidebar-accent-foreground/70">
                <MapPin className="h-4 w-4 mt-0.5 shrink-0" />
                <span>Campus Universitário, Bloco A - Agronomia</span>
              </li>
              <li className="flex items-center gap-2 text-sm text-sidebar-accent-foreground/70">
                <Phone className="h-4 w-4 shrink-0" />
                <span>(11) 1234-5678</span>
              </li>
              <li className="flex items-center gap-2 text-sm text-sidebar-accent-foreground/70">
                <Mail className="h-4 w-4 shrink-0" />
                <span>contato@citahub.com.br</span>
              </li>
            </ul>

            {/* Social Links */}
            <div className="mt-6 flex gap-4">
              {navigation.social.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-sidebar-accent transition-colors hover:bg-sidebar-primary"
                >
                  <item.icon className="h-4 w-4" />
                  <span className="sr-only">{item.name}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-12 border-t border-sidebar-border pt-8">
          <p className="text-center text-xs text-sidebar-accent-foreground/60">
            © {new Date().getFullYear()} CITA Hub - Centro de Inovação e Tecnologia Agrícola. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}
