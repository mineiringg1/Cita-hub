import Image from "next/image"
import Link from "next/link"
import { ArrowRight, Calendar, User } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

const featuredNews = [
  {
    id: 1,
    slug: "agricultura-de-precisao-revolucionando-o-campo",
    title: "Agricultura de Precisão: Como a tecnologia está revolucionando o campo brasileiro",
    excerpt: "Descubra como drones, sensores IoT e inteligência artificial estão transformando a forma como produzimos alimentos e aumentando a eficiência no agronegócio.",
    image: "/images/technology.jpg",
    category: "Tecnologia",
    author: "Ana Clara Mendes",
    date: "15 Mar 2026",
    featured: true,
  },
  {
    id: 2,
    slug: "praticas-sustentaveis-certificacoes-verdes",
    title: "Práticas Sustentáveis e Certificações Verdes",
    excerpt: "Um guia completo sobre como implementar práticas sustentáveis na sua propriedade e obter certificações ambientais.",
    image: "/images/sustainability.jpg",
    category: "Sustentabilidade",
    author: "Pedro Oliveira",
    date: "12 Mar 2026",
    featured: false,
  },
  {
    id: 3,
    slug: "pesquisa-variedades-resistentes-seca",
    title: "Nova Pesquisa: Variedades Resistentes à Seca",
    excerpt: "Estudo desenvolvido em parceria com a Embrapa revela novas variedades de milho e soja com maior resistência ao estresse hídrico.",
    image: "/images/research.jpg",
    category: "Pesquisa",
    author: "Juliana Costa",
    date: "10 Mar 2026",
    featured: false,
  },
]

const categoryColors: Record<string, string> = {
  Tecnologia: "bg-blue-500/10 text-blue-700 border-blue-200",
  Sustentabilidade: "bg-primary/10 text-primary border-primary/20",
  Pesquisa: "bg-accent/10 text-accent border-accent/20",
  Inovação: "bg-purple-500/10 text-purple-700 border-purple-200",
}

export function FeaturedNewsSection() {
  const mainNews = featuredNews.find((n) => n.featured)
  const sideNews = featuredNews.filter((n) => !n.featured)

  return (
    <section className="py-24 bg-background">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-end justify-between mb-12">
          <div>
            <p className="text-sm font-medium uppercase tracking-widest text-primary mb-3">
              Boletins
            </p>
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Últimas Publicações
            </h2>
          </div>
          <Button variant="outline" asChild className="hidden sm:flex">
            <Link href="/boletins">
              Ver todos
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>

        {/* News Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Main Featured */}
          {mainNews && (
            <Link
              href={`/boletins/${mainNews.slug}`}
              className="group relative h-[500px] rounded-2xl overflow-hidden"
            >
              <Image
                src={mainNews.image}
                alt={mainNews.title}
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/90 via-foreground/40 to-transparent" />

              <div className="absolute bottom-0 left-0 right-0 p-8">
                <Badge className={categoryColors[mainNews.category]}>
                  {mainNews.category}
                </Badge>
                <h3 className="mt-4 text-2xl font-bold text-primary-foreground group-hover:text-primary transition-colors text-balance">
                  {mainNews.title}
                </h3>
                <p className="mt-2 text-sm text-primary-foreground/80 line-clamp-2">
                  {mainNews.excerpt}
                </p>
                <div className="mt-4 flex items-center gap-4 text-xs text-primary-foreground/60">
                  <span className="flex items-center gap-1">
                    <User className="h-3 w-3" />
                    {mainNews.author}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {mainNews.date}
                  </span>
                </div>
              </div>
            </Link>
          )}

          {/* Side News */}
          <div className="flex flex-col gap-6">
            {sideNews.map((news) => (
              <Link
                key={news.id}
                href={`/boletins/${news.slug}`}
                className="group flex gap-6 p-4 rounded-xl bg-card border border-border hover:border-primary/30 hover:shadow-lg transition-all"
              >
                <div className="relative w-32 h-32 shrink-0 rounded-lg overflow-hidden">
                  <Image
                    src={news.image}
                    alt={news.title}
                    fill
                    className="object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <div className="flex flex-col justify-center">
                  <Badge className={`${categoryColors[news.category]} w-fit`}>
                    {news.category}
                  </Badge>
                  <h3 className="mt-2 font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-2 text-balance">
                    {news.title}
                  </h3>
                  <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <User className="h-3 w-3" />
                      {news.author}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {news.date}
                    </span>
                  </div>
                </div>
              </Link>
            ))}

            {/* CTA Card */}
            <div className="flex-1 flex flex-col items-center justify-center p-8 rounded-xl bg-primary/5 border border-primary/20 text-center">
              <h3 className="text-lg font-semibold text-foreground">
                Quer receber nossos boletins?
              </h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Inscreva-se para receber as últimas novidades do agronegócio.
              </p>
              <Button className="mt-4" asChild>
                <Link href="/contato">Inscrever-se</Link>
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile CTA */}
        <div className="mt-8 sm:hidden">
          <Button variant="outline" className="w-full" asChild>
            <Link href="/boletins">
              Ver todos os boletins
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
