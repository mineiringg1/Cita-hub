import Image from "next/image"
import Link from "next/link"
import { ArrowRight, Sprout, Users, BookOpen } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/hero-agro.jpg"
          alt="Agricultura sustentável"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-foreground/90 via-foreground/70 to-foreground/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-7xl px-6 py-32 lg:px-8">
        <div className="max-w-2xl">
          <p className="text-sm font-medium uppercase tracking-widest text-primary-foreground/80 mb-4">
            Centro de Inovação e Tecnologia Agrícola
          </p>
          <h1 className="text-4xl font-bold tracking-tight text-primary-foreground sm:text-5xl lg:text-6xl text-balance leading-tight">
            Cultivando o futuro da agricultura brasileira
          </h1>
          <p className="mt-6 text-lg leading-relaxed text-primary-foreground/80 text-pretty">
            Somos estudantes de Agronomia e Agronegócio unidos pela paixão em transformar o campo através da inovação, sustentabilidade e tecnologia de ponta.
          </p>

          <div className="mt-10 flex flex-col sm:flex-row gap-4">
            <Button size="lg" asChild>
              <Link href="/boletins">
                Nossos Boletins
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="bg-transparent border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10" asChild>
              <Link href="/equipe">Conheça a Equipe</Link>
            </Button>
          </div>

          {/* Stats */}
          <div className="mt-16 grid grid-cols-3 gap-8">
            <div className="flex flex-col">
              <div className="flex items-center gap-2 text-primary">
                <Sprout className="h-5 w-5" />
                <span className="text-2xl font-bold text-primary-foreground">50+</span>
              </div>
              <span className="text-sm text-primary-foreground/60 mt-1">Publicações</span>
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-2 text-primary">
                <Users className="h-5 w-5" />
                <span className="text-2xl font-bold text-primary-foreground">12</span>
              </div>
              <span className="text-sm text-primary-foreground/60 mt-1">Membros</span>
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-2 text-primary">
                <BookOpen className="h-5 w-5" />
                <span className="text-2xl font-bold text-primary-foreground">8</span>
              </div>
              <span className="text-sm text-primary-foreground/60 mt-1">Projetos</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
