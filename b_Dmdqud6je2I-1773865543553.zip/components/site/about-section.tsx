import Image from "next/image"
import { Target, Lightbulb, Leaf } from "lucide-react"

const pillars = [
  {
    icon: Lightbulb,
    title: "Inovação",
    description: "Desenvolvemos e compartilhamos conhecimento sobre as mais recentes tecnologias aplicadas ao agronegócio.",
  },
  {
    icon: Leaf,
    title: "Sustentabilidade",
    description: "Promovemos práticas agrícolas que respeitam o meio ambiente e garantem a produtividade a longo prazo.",
  },
  {
    icon: Target,
    title: "Educação",
    description: "Formamos profissionais capacitados para os desafios do campo moderno através de pesquisa e extensão.",
  },
]

export function AboutSection() {
  return (
    <section className="py-24 bg-card">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto">
          <p className="text-sm font-medium uppercase tracking-widest text-primary mb-3">
            Sobre Nós
          </p>
          <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl text-balance">
            Unindo inovação, durabilidade e eficiência
          </h2>
          <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
            O CITA Hub nasceu da união de estudantes apaixonados por transformar a agricultura brasileira através do conhecimento e da tecnologia.
          </p>
        </div>

        {/* Image and Text */}
        <div className="mt-16 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="relative h-[400px] rounded-2xl overflow-hidden">
            <Image
              src="/images/innovation.jpg"
              alt="Inovação no campo"
              fill
              className="object-cover"
            />
          </div>

          <div>
            <h3 className="text-2xl font-semibold text-foreground">
              Uma abordagem global para um modelo de futuro
            </h3>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              Acreditamos que o futuro do agronegócio está na integração entre tecnologia de ponta, práticas sustentáveis e conhecimento acadêmico. Nossa missão é ser a ponte entre a universidade e o campo, levando inovação para quem produz.
            </p>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              Através de boletins informativos, eventos e projetos de pesquisa, disseminamos conhecimento que impacta diretamente a produtividade e sustentabilidade do agronegócio brasileiro.
            </p>
          </div>
        </div>

        {/* Pillars */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8">
          {pillars.map((pillar, index) => (
            <div
              key={pillar.title}
              className="relative p-8 rounded-2xl bg-muted/50 border border-border hover:border-primary/30 transition-colors"
            >
              <div className="text-5xl font-bold text-primary/20 absolute top-4 right-6">
                {index + 1}
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <pillar.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-foreground">
                {pillar.title}
              </h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                {pillar.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
