import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export function CTASection() {
  return (
    <section className="py-24 bg-sidebar">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-sidebar-foreground sm:text-4xl text-balance">
            Vamos conversar sobre seu projeto?
          </h2>
          <p className="mt-4 text-lg text-sidebar-accent-foreground/80 leading-relaxed">
            Entre em contato conosco para parcerias, dúvidas ou para saber mais sobre nossas iniciativas.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/contato">
                Fale Conosco
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent border-sidebar-accent-foreground/30 text-sidebar-foreground hover:bg-sidebar-accent"
              asChild
            >
              <Link href="/eventos">Ver Eventos</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
