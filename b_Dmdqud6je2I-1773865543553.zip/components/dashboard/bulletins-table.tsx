'use client'

import { Pencil, Trash2 } from 'lucide-react'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface Bulletin {
  id: string
  title: string
  author: string
  publishedAt: string
  status: 'published' | 'draft'
}

const bulletins: Bulletin[] = [
  {
    id: '1',
    title: 'Novas técnicas de irrigação sustentável para o cerrado',
    author: 'Maria Silva',
    publishedAt: '15 Mar 2026',
    status: 'published',
  },
  {
    id: '2',
    title: 'Análise de mercado: Soja safra 2025/2026',
    author: 'João Pereira',
    publishedAt: '14 Mar 2026',
    status: 'published',
  },
  {
    id: '3',
    title: 'Implementação de drones na agricultura de precisão',
    author: 'Ana Costa',
    publishedAt: '12 Mar 2026',
    status: 'draft',
  },
  {
    id: '4',
    title: 'Manejo integrado de pragas em lavouras de milho',
    author: 'Carlos Mendes',
    publishedAt: '10 Mar 2026',
    status: 'published',
  },
  {
    id: '5',
    title: 'Biotecnologia e melhoramento genético vegetal',
    author: 'Fernanda Lima',
    publishedAt: '08 Mar 2026',
    status: 'draft',
  },
  {
    id: '6',
    title: 'Sistemas agroflorestais: casos de sucesso no Brasil',
    author: 'Ricardo Santos',
    publishedAt: '05 Mar 2026',
    status: 'published',
  },
]

export function BulletinsTable() {
  return (
    <div className="rounded-xl border border-border bg-card shadow-sm">
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent">
            <TableHead className="w-[40%]">Título</TableHead>
            <TableHead>Autor</TableHead>
            <TableHead>Data de Publicação</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {bulletins.map((bulletin) => (
            <TableRow key={bulletin.id}>
              <TableCell className="font-medium">{bulletin.title}</TableCell>
              <TableCell className="text-muted-foreground">
                {bulletin.author}
              </TableCell>
              <TableCell className="text-muted-foreground">
                {bulletin.publishedAt}
              </TableCell>
              <TableCell>
                <Badge
                  className={cn(
                    'font-medium',
                    bulletin.status === 'published'
                      ? 'border-transparent bg-primary/15 text-primary hover:bg-primary/15'
                      : 'border-transparent bg-amber-500/15 text-amber-600 hover:bg-amber-500/15'
                  )}
                >
                  {bulletin.status === 'published' ? 'Publicado' : 'Rascunho'}
                </Badge>
              </TableCell>
              <TableCell className="text-right">
                <div className="flex items-center justify-end gap-1">
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    className="text-muted-foreground hover:text-primary"
                  >
                    <Pencil className="size-4" />
                    <span className="sr-only">Editar</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    className="text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="size-4" />
                    <span className="sr-only">Excluir</span>
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
