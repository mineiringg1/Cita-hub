# Painel Administrativo - Setup e Uso

## O que foi implementado

A estrutura de integração com banco de dados (Supabase) foi completamente configurada para o painel administrativo:

### 1. Configuração do Supabase
- **Arquivo**: `src/config/supabase.ts`
- Inicializa o cliente Supabase usando variáveis de ambiente
- Verifica se as credenciais estão configuradas
- Fornece fallback automático para dados mockados se não configurado

### 2. Serviço de Banco de Dados
- **Arquivo**: `src/services/db.ts`
- Funções CRUD completas para Boletins e Eventos:
  - `getBoletins()` - Busca todos os artigos
  - `getBoletimById(id)` - Busca um artigo específico
  - `addBoletim(data)` - Cria novo artigo
  - `updateBoletim(id, updates)` - Atualiza artigo
  - `deleteBoletim(id)` - Deleta artigo
  - Mesmas funções para Eventos (`getEventos`, `addEvento`, etc.)

### 3. Painel Administrativo
- **URL**: `/admin`
- **Arquivo**: `src/pages/Admin.tsx`
- Dashboard com:
  - Estatísticas (contadores)
  - Formulário para criar novos boletins
  - Tabela com lista de boletins
  - Indicador de carregamento durante operações
  - Mensagens de sucesso/erro
  - Atualização automática após criar/deletar

### 4. Fallback Automático
- Se as credenciais Supabase não estiverem preenchidas, a aplicação:
  - Usa dados mockados locais
  - Não quebra a interface
  - Permite visualizar o visual completo
  - Mostra logs no console indicando uso de dados mockados

## Como usar

### Sem credenciais (Desenvolvimento)
A aplicação já está funcionando com dados mockados. Acesse `/admin` para ver o painel.

### Com credenciais Supabase
1. Copie seu `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` do dashboard do Supabase
2. Adicione ao arquivo `.env`:
   ```
   VITE_SUPABASE_URL=https://seu-projeto.supabase.co
   VITE_SUPABASE_ANON_KEY=sua-chave-anonima
   ```
3. As tabelas serão criadas automaticamente na primeira execução
4. Todas as operações serão persistidas no banco de dados

## Estrutura de Dados

### Tabela: boletins
- `id` (UUID)
- `title` (texto)
- `summary` (texto)
- `content` (texto)
- `category` (texto)
- `image` (URL)
- `date` (data)
- `created_at`, `updated_at` (timestamps)

### Tabela: eventos
- `id` (UUID)
- `title` (texto)
- `description` (texto)
- `date`, `time` (data e hora)
- `location` (local)
- `category` (Workshop, Palestra, Atividade)
- `image` (URL)
- `capacity`, `registered` (números)
- `created_at`, `updated_at` (timestamps)

## Próximos Passos

1. **Autenticação**: Adicionar login para o painel
2. **Edição**: Implementar funcionalidade de editar boletins
3. **Upload de Imagens**: Integrar com Supabase Storage
4. **Validações**: Adicionar validações mais robustas
5. **Eventos**: Criar painel similar para eventos
