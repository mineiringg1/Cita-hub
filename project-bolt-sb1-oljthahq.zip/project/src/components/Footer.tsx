export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#2D5016] text-white mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
          <div className="text-center sm:text-left">
            <p className="text-sm font-semibold">CITA Hub</p>
            <p className="text-xs text-gray-300 mt-1">Centro de Inovação e Tecnologia Agrícola</p>
          </div>

          <div className="text-center sm:text-right">
            <p className="text-xs text-gray-300">
              © {currentYear} CITA. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
