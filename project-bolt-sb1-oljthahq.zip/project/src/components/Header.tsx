import { Link, useLocation } from 'react-router-dom';
import { Leaf } from 'lucide-react';

export default function Header() {
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2 group">
            <div className="bg-gradient-to-br from-[#2D5016] to-[#4A7C2C] p-2 rounded-lg group-hover:scale-105 transition-transform">
              <Leaf className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-[#2D5016]">CITA Hub</h1>
              <p className="text-xs text-gray-600 hidden sm:block">Centro de Inovação e Tecnologia Agrícola</p>
            </div>
          </Link>

          <nav className="flex space-x-1 sm:space-x-4">
            <Link
              to="/"
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                isActive('/')
                  ? 'bg-[#2D5016] text-white'
                  : 'text-gray-700 hover:bg-[#F5F5F5] hover:text-[#2D5016]'
              }`}
            >
              Boletins
            </Link>
            <Link
              to="/biblioteca"
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                isActive('/biblioteca')
                  ? 'bg-[#2D5016] text-white'
                  : 'text-gray-700 hover:bg-[#F5F5F5] hover:text-[#2D5016]'
              }`}
            >
              Biblioteca
            </Link>
            <Link
              to="/eventos"
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                isActive('/eventos')
                  ? 'bg-[#2D5016] text-white'
                  : 'text-gray-700 hover:bg-[#F5F5F5] hover:text-[#2D5016]'
              }`}
            >
              Eventos
            </Link>
            <Link
              to="/sobre"
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                isActive('/sobre')
                  ? 'bg-[#2D5016] text-white'
                  : 'text-gray-700 hover:bg-[#F5F5F5] hover:text-[#2D5016]'
              }`}
            >
              Sobre
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
