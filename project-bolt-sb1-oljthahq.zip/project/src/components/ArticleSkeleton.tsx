export default function ArticleSkeleton() {
  return (
    <div className="group flex flex-col h-full bg-white rounded-lg overflow-hidden shadow-md border border-gray-100 animate-pulse">
      <div className="w-full h-48 bg-gray-200"></div>

      <div className="flex flex-col flex-1 p-6">
        <div className="h-6 bg-gray-200 rounded mb-3 w-3/4"></div>
        <div className="h-4 bg-gray-200 rounded mb-2 w-full"></div>
        <div className="h-4 bg-gray-200 rounded mb-4 w-5/6"></div>

        <div className="flex-1"></div>

        <div className="pt-4 border-t border-gray-100 mb-6">
          <div className="h-3 bg-gray-200 rounded w-1/3"></div>
        </div>

        <div className="h-10 bg-gray-200 rounded-lg w-full"></div>
      </div>
    </div>
  );
}
