export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  category: 'Workshop' | 'Palestra' | 'Atividade';
  image: string;
  capacity: number;
  registered: number;
}

const mockEvents: Event[] = [
  {
    id: '1',
    title: 'Workshop: Agricultura de Precisão com IoT',
    description: 'Aprenda como implementar sensores e automação na sua propriedade para otimizar recursos e aumentar produtividade.',
    date: '2026-03-28',
    time: '09:00',
    location: 'Auditório Principal - CITA Hub',
    category: 'Workshop',
    image: 'https://images.pexels.com/photos/3808517/pexels-photo-3808517.jpeg?auto=compress&cs=tinysrgb&w=600',
    capacity: 50,
    registered: 42,
  },
  {
    id: '2',
    title: 'Palestra: Tendências de Mercado Agrícola 2026',
    description: 'Especialistas discutem os principais trends e oportunidades no mercado de commodities agrícolas para este ano.',
    date: '2026-03-30',
    time: '14:30',
    location: 'Sala de Conferências - Ala Norte',
    category: 'Palestra',
    image: 'https://images.pexels.com/photos/5632399/pexels-photo-5632399.jpeg?auto=compress&cs=tinysrgb&w=600',
    capacity: 120,
    registered: 95,
  },
  {
    id: '3',
    title: 'Atividade: Dia de Campo - Sustentabilidade em Ação',
    description: 'Visita prática a propriedade modelo onde será possível observar técnicas sustentáveis em operação real.',
    date: '2026-04-05',
    time: '08:00',
    location: 'Fazenda Experimental - Bairro Rural',
    category: 'Atividade',
    image: 'https://images.pexels.com/photos/5626516/pexels-photo-5626516.jpeg?auto=compress&cs=tinysrgb&w=600',
    capacity: 80,
    registered: 65,
  },
  {
    id: '4',
    title: 'Workshop: Melhoramento Genético de Plantas',
    description: 'Técnicas modernas de seleção e cruzamento de plantas para obter variedades mais produtivas e resilientes.',
    date: '2026-04-08',
    time: '10:00',
    location: 'Laboratório de Inovação - CITA Hub',
    category: 'Workshop',
    image: 'https://images.pexels.com/photos/3944441/pexels-photo-3944441.jpeg?auto=compress&cs=tinysrgb&w=600',
    capacity: 35,
    registered: 28,
  },
  {
    id: '5',
    title: 'Palestra: Certificações e Conformidade Agrícola',
    description: 'Entenda os requisitos legais e as certificações necessárias para alcançar novos mercados internacionais.',
    date: '2026-04-12',
    time: '15:00',
    location: 'Auditório Principal - CITA Hub',
    category: 'Palestra',
    image: 'https://images.pexels.com/photos/5632421/pexels-photo-5632421.jpeg?auto=compress&cs=tinysrgb&w=600',
    capacity: 100,
    registered: 72,
  },
  {
    id: '6',
    title: 'Atividade: Simulação de Gestão de Fazenda',
    description: 'Jogo interativo onde os participantes gerenciam uma propriedade virtual e aprendem sobre decisões estratégicas.',
    date: '2026-04-18',
    time: '13:00',
    location: 'Sala de Treinamento - CITA Hub',
    category: 'Atividade',
    image: 'https://images.pexels.com/photos/3965521/pexels-photo-3965521.jpeg?auto=compress&cs=tinysrgb&w=600',
    capacity: 60,
    registered: 54,
  },
];

export async function fetchEvents(): Promise<Event[]> {
  try {
    const { getEventos } = await import('../db');
    const eventos = await getEventos();
    return eventos;
  } catch (error) {
    console.error('Error fetching events from DB, using mock data:', error);
    return new Promise((resolve) => {
      setTimeout(() => {
        const sortedEvents = [...mockEvents].sort((a, b) => {
          const dateA = new Date(`${a.date}T${a.time}`);
          const dateB = new Date(`${b.date}T${b.time}`);
          return dateA.getTime() - dateB.getTime();
        });
        resolve(sortedEvents);
      }, 1000);
    });
  }
}

export async function fetchEventById(eventId: string): Promise<Event | null> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const event = mockEvents.find((e) => e.id === eventId);
      resolve(event || null);
    }, 800);
  });
}
