interface Article {
  id: number;
  title: string;
  summary: string;
  date: string;
  image: string;
  category: string;
}

const articlesData: Article[] = [
  {
    id: 1,
    title: "Tecnologia de Precisão Revoluciona Cultivo de Grãos",
    summary: "Agricultores adotam sensores IoT para monitorar umidade do solo em tempo real, aumentando produtividade em até 30%.",
    date: "15 de março de 2026",
    image: "https://images.pexels.com/photos/3944441/pexels-photo-3944441.jpeg?auto=compress&cs=tinysrgb&w=600",
    category: "Tecnologia"
  },
  {
    id: 2,
    title: "Sustentabilidade no Campo: Agricultura Regenerativa Ganha Força",
    summary: "Práticas de rotação de culturas e cobertura vegetal restauram saúde do solo enquanto reduzem custos com insumos.",
    date: "12 de março de 2026",
    image: "https://images.pexels.com/photos/4551832/pexels-photo-4551832.jpeg?auto=compress&cs=tinysrgb&w=600",
    category: "Sustentabilidade"
  },
  {
    id: 3,
    title: "Drones Agrícolas Transformam Manejo de Pragas",
    summary: "Aplicação aérea de defensivos com drones reduz desperdício em 60% e protege a saúde do operador.",
    date: "8 de março de 2026",
    image: "https://images.pexels.com/photos/699122/pexels-photo-699122.jpeg?auto=compress&cs=tinysrgb&w=600",
    category: "Inovação"
  },
  {
    id: 4,
    title: "IA Prevê Melhor Época para Colheita com Precisão Milimétrica",
    summary: "Algoritmos de machine learning analisam dados climáticos e fenológicos para definir o momento ideal de colheita.",
    date: "5 de março de 2026",
    image: "https://images.pexels.com/photos/6118476/pexels-photo-6118476.jpeg?auto=compress&cs=tinysrgb&w=600",
    category: "Inteligência Artificial"
  },
  {
    id: 5,
    title: "Parcerias Público-Privadas Impulsionam Pesquisa Agrícola",
    summary: "Iniciativas colaborativas entre universidades e startups aceleram transferência de tecnologia para pequenos produtores.",
    date: "1º de março de 2026",
    image: "https://images.pexels.com/photos/4239064/pexels-photo-4239064.jpeg?auto=compress&cs=tinysrgb&w=600",
    category: "Inovação"
  }
];

export async function fetchArticles(): Promise<Article[]> {
  try {
    const { getBoletins } = await import('../db');
    const boletins = await getBoletins();
    return boletins.map((b) => ({
      id: parseInt(b.id.substring(0, 8), 16) || Math.random() * 10000,
      title: b.title,
      summary: b.summary,
      category: b.category,
      image: b.image,
      date: b.date,
    }));
  } catch (error) {
    console.error('Error fetching articles from DB, using mock data:', error);
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(articlesData);
      }, 1000);
    });
  }
}

export type { Article };
