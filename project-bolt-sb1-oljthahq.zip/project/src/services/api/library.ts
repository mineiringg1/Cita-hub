export interface LibraryItem {
  id: string;
  title: string;
  description: string;
  resources: number;
  image: string;
}

export interface Axis {
  id: string;
  name: string;
  color: string;
  description: string;
  items: LibraryItem[];
}

const mockAxes: Axis[] = [
  {
    id: '1',
    name: 'Sustentabilidade',
    color: 'from-green-500 to-emerald-600',
    description: 'Práticas sustentáveis e preservação ambiental na agricultura moderna',
    items: [
      {
        id: '1-1',
        title: 'Agricultura de Precisão Sustentável',
        description: 'Técnicas de uso eficiente de água e nutrientes',
        resources: 12,
        image: 'https://images.pexels.com/photos/5626516/pexels-photo-5626516.jpeg?auto=compress&cs=tinysrgb&w=400',
      },
      {
        id: '1-2',
        title: 'Manejo de Solo e Biodiversidade',
        description: 'Estratégias para manter a saúde do solo',
        resources: 8,
        image: 'https://images.pexels.com/photos/5632399/pexels-photo-5632399.jpeg?auto=compress&cs=tinysrgb&w=400',
      },
      {
        id: '1-3',
        title: 'Energia Renovável na Fazenda',
        description: 'Integração de fontes renováveis na produção agrícola',
        resources: 15,
        image: 'https://images.pexels.com/photos/3808517/pexels-photo-3808517.jpeg?auto=compress&cs=tinysrgb&w=400',
      },
    ],
  },
  {
    id: '2',
    name: 'Produção Vegetal',
    color: 'from-yellow-500 to-amber-600',
    description: 'Inovações em cultivos e técnicas de plantio avançadas',
    items: [
      {
        id: '2-1',
        title: 'Melhoramento Genético de Plantas',
        description: 'Desenvolvimento de variedades mais produtivas',
        resources: 20,
        image: 'https://images.pexels.com/photos/5632402/pexels-photo-5632402.jpeg?auto=compress&cs=tinysrgb&w=400',
      },
      {
        id: '2-2',
        title: 'Controle Biológico de Pragas',
        description: 'Alternativas naturais ao uso de pesticidas',
        resources: 11,
        image: 'https://images.pexels.com/photos/5632421/pexels-photo-5632421.jpeg?auto=compress&cs=tinysrgb&w=400',
      },
      {
        id: '2-3',
        title: 'Sistemas de Irrigação Inteligentes',
        description: 'IoT e automação para otimizar recursos hídricos',
        resources: 17,
        image: 'https://images.pexels.com/photos/5632394/pexels-photo-5632394.jpeg?auto=compress&cs=tinysrgb&w=400',
      },
    ],
  },
  {
    id: '3',
    name: 'Gestão',
    color: 'from-blue-500 to-cyan-600',
    description: 'Ferramentas e metodologias para gestão eficiente da propriedade',
    items: [
      {
        id: '3-1',
        title: 'Gestão Financeira Agrícola',
        description: 'Análise de custos e rentabilidade das operações',
        resources: 14,
        image: 'https://images.pexels.com/photos/3965521/pexels-photo-3965521.jpeg?auto=compress&cs=tinysrgb&w=400',
      },
      {
        id: '3-2',
        title: 'Planejamento Estratégico da Fazenda',
        description: 'Visão de longo prazo e diversificação de cultivos',
        resources: 9,
        image: 'https://images.pexels.com/photos/5632403/pexels-photo-5632403.jpeg?auto=compress&cs=tinysrgb&w=400',
      },
      {
        id: '3-3',
        title: 'Certificações e Conformidade',
        description: 'Requisitos legais e certificações de qualidade',
        resources: 13,
        image: 'https://images.pexels.com/photos/3944441/pexels-photo-3944441.jpeg?auto=compress&cs=tinysrgb&w=400',
      },
    ],
  },
];

export async function fetchLibraryAxes(): Promise<Axis[]> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockAxes);
    }, 1000);
  });
}

export async function fetchAxisById(axisId: string): Promise<Axis | null> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const axis = mockAxes.find((a) => a.id === axisId);
      resolve(axis || null);
    }, 800);
  });
}
