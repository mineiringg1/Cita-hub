import { getSupabaseClient, isSupabaseConfigured } from '../config/supabase';
import { fetchArticles as getMockArticles } from './api/articles';
import { fetchEvents as getMockEvents } from './api/events';

export interface SiteSettings {
  id?: string;
  logo_url: string;
  mission: string;
  vision: string;
  values: string;
  contact_email: string;
  phone: string;
  address: string;
  updated_at?: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  bio: string;
  photo_url: string;
  order: number;
  created_at?: string;
  updated_at?: string;
}

export interface Boletim {
  id: string;
  title: string;
  summary: string;
  content?: string;
  category: string;
  image: string;
  date: string;
  created_at?: string;
  updated_at?: string;
}

export interface Evento {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  category: 'Workshop' | 'Palestra' | 'Atividade';
  image: string;
  capacity: number;
  registered: number;
  created_at?: string;
  updated_at?: string;
}

const BOLETINS_TABLE = 'boletins';
const EVENTOS_TABLE = 'eventos';
const SITE_SETTINGS_TABLE = 'site_settings';
const TEAM_MEMBERS_TABLE = 'team_members';
const UPLOADS_BUCKET = 'uploads';

export async function uploadImage(file: File, folder: string = 'images'): Promise<string> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Mock: Uploading image (not persisted)');
    return URL.createObjectURL(file);
  }

  try {
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}.${fileExt}`;
    const filePath = `${folder}/${fileName}`;

    const { error: uploadError } = await client.storage
      .from(UPLOADS_BUCKET)
      .upload(filePath, file, { upsert: false });

    if (uploadError) throw uploadError;

    const { data } = client.storage.from(UPLOADS_BUCKET).getPublicUrl(filePath);
    return data.publicUrl;
  } catch (error) {
    console.error('Error uploading image:', error);
    throw error;
  }
}

export async function deleteImage(filePath: string): Promise<boolean> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    return true;
  }

  try {
    const { error } = await client.storage.from(UPLOADS_BUCKET).remove([filePath]);
    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error deleting image:', error);
    return false;
  }
}

export async function getBoletins(): Promise<Boletim[]> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Using mock boletins data');
    const mockData = await getMockArticles();
    return mockData.map((article) => ({
      id: article.id,
      title: article.title,
      summary: article.summary,
      category: article.category,
      image: article.image,
      date: article.date,
    }));
  }

  try {
    const { data, error } = await client
      .from(BOLETINS_TABLE)
      .select('*')
      .order('date', { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching boletins:', error);
    const mockData = await getMockArticles();
    return mockData.map((article) => ({
      id: article.id,
      title: article.title,
      summary: article.summary,
      category: article.category,
      image: article.image,
      date: article.date,
    }));
  }
}

export async function getBoletimById(id: string): Promise<Boletim | null> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Using mock boletim data');
    const mockData = await getMockArticles();
    const article = mockData.find((a) => a.id === id);
    return article
      ? {
          id: article.id,
          title: article.title,
          summary: article.summary,
          category: article.category,
          image: article.image,
          date: article.date,
        }
      : null;
  }

  try {
    const { data, error } = await client
      .from(BOLETINS_TABLE)
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data || null;
  } catch (error) {
    console.error('Error fetching boletim:', error);
    return null;
  }
}

export async function addBoletim(boletim: Omit<Boletim, 'id' | 'created_at' | 'updated_at'>): Promise<Boletim | null> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Mock: Adding boletim (not persisted)');
    return {
      id: Math.random().toString(36).substr(2, 9),
      ...boletim,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
  }

  try {
    const { data, error } = await client
      .from(BOLETINS_TABLE)
      .insert([boletim])
      .select()
      .maybeSingle();

    if (error) throw error;
    return data || null;
  } catch (error) {
    console.error('Error adding boletim:', error);
    throw error;
  }
}

export async function updateBoletim(
  id: string,
  updates: Partial<Omit<Boletim, 'id' | 'created_at'>>,
): Promise<Boletim | null> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Mock: Updating boletim (not persisted)');
    return {
      id,
      ...updates,
      title: updates.title || '',
      summary: updates.summary || '',
      category: updates.category || '',
      image: updates.image || '',
      date: updates.date || '',
    };
  }

  try {
    const { data, error } = await client
      .from(BOLETINS_TABLE)
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .maybeSingle();

    if (error) throw error;
    return data || null;
  } catch (error) {
    console.error('Error updating boletim:', error);
    throw error;
  }
}

export async function deleteBoletim(id: string): Promise<boolean> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Mock: Deleting boletim (not persisted)');
    return true;
  }

  try {
    const { error } = await client.from(BOLETINS_TABLE).delete().eq('id', id);

    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error deleting boletim:', error);
    throw error;
  }
}

export async function getEventos(): Promise<Evento[]> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Using mock eventos data');
    const mockData = await getMockEvents();
    return mockData;
  }

  try {
    const { data, error } = await client
      .from(EVENTOS_TABLE)
      .select('*')
      .order('date', { ascending: true });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching eventos:', error);
    const mockData = await getMockEvents();
    return mockData;
  }
}

export async function getEventoById(id: string): Promise<Evento | null> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Using mock evento data');
    const mockData = await getMockEvents();
    const event = mockData.find((e) => e.id === id);
    return event || null;
  }

  try {
    const { data, error } = await client
      .from(EVENTOS_TABLE)
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data || null;
  } catch (error) {
    console.error('Error fetching evento:', error);
    return null;
  }
}

export async function addEvento(evento: Omit<Evento, 'id' | 'created_at' | 'updated_at'>): Promise<Evento | null> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Mock: Adding evento (not persisted)');
    return {
      id: Math.random().toString(36).substr(2, 9),
      ...evento,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
  }

  try {
    const { data, error } = await client
      .from(EVENTOS_TABLE)
      .insert([evento])
      .select()
      .maybeSingle();

    if (error) throw error;
    return data || null;
  } catch (error) {
    console.error('Error adding evento:', error);
    throw error;
  }
}

export async function updateEvento(
  id: string,
  updates: Partial<Omit<Evento, 'id' | 'created_at'>>,
): Promise<Evento | null> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Mock: Updating evento (not persisted)');
    return {
      id,
      ...updates,
      title: updates.title || '',
      description: updates.description || '',
      date: updates.date || '',
      time: updates.time || '',
      location: updates.location || '',
      category: updates.category || 'Workshop',
      image: updates.image || '',
      capacity: updates.capacity || 50,
      registered: updates.registered || 0,
    };
  }

  try {
    const { data, error } = await client
      .from(EVENTOS_TABLE)
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .maybeSingle();

    if (error) throw error;
    return data || null;
  } catch (error) {
    console.error('Error updating evento:', error);
    throw error;
  }
}

export async function deleteEvento(id: string): Promise<boolean> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Mock: Deleting evento (not persisted)');
    return true;
  }

  try {
    const { error } = await client.from(EVENTOS_TABLE).delete().eq('id', id);

    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error deleting evento:', error);
    throw error;
  }
}

export async function getSiteSettings(): Promise<SiteSettings> {
  const client = getSupabaseClient();

  const defaultSettings: SiteSettings = {
    logo_url: '',
    mission: 'Promover a agricultura sustentável e inovadora',
    vision: 'Ser referência em práticas agrícolas modernas',
    values: 'Inovação, Sustentabilidade, Colaboração',
    contact_email: 'contato@citahub.com.br',
    phone: '(11) 1234-5678',
    address: 'Rua Principal, 123 - São Paulo',
  };

  if (!client || !isSupabaseConfigured()) {
    console.log('Using default site settings');
    return defaultSettings;
  }

  try {
    const { data, error } = await client
      .from(SITE_SETTINGS_TABLE)
      .select('*')
      .maybeSingle();

    if (error) throw error;
    return data || defaultSettings;
  } catch (error) {
    console.error('Error fetching site settings:', error);
    return defaultSettings;
  }
}

export async function updateSiteSettings(updates: Partial<SiteSettings>): Promise<SiteSettings | null> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Mock: Updating site settings (not persisted)');
    return updates as SiteSettings;
  }

  try {
    const current = await getSiteSettings();
    const { data, error } = await client
      .from(SITE_SETTINGS_TABLE)
      .upsert({ ...current, ...updates, updated_at: new Date().toISOString() })
      .select()
      .maybeSingle();

    if (error) throw error;
    return data || null;
  } catch (error) {
    console.error('Error updating site settings:', error);
    throw error;
  }
}

export async function getTeamMembers(): Promise<TeamMember[]> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Using mock team members data');
    return [];
  }

  try {
    const { data, error } = await client
      .from(TEAM_MEMBERS_TABLE)
      .select('*')
      .order('order', { ascending: true });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching team members:', error);
    return [];
  }
}

export async function addTeamMember(member: Omit<TeamMember, 'id' | 'created_at' | 'updated_at'>): Promise<TeamMember | null> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Mock: Adding team member (not persisted)');
    return {
      id: Math.random().toString(36).substr(2, 9),
      ...member,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
  }

  try {
    const { data, error } = await client
      .from(TEAM_MEMBERS_TABLE)
      .insert([member])
      .select()
      .maybeSingle();

    if (error) throw error;
    return data || null;
  } catch (error) {
    console.error('Error adding team member:', error);
    throw error;
  }
}

export async function updateTeamMember(
  id: string,
  updates: Partial<Omit<TeamMember, 'id' | 'created_at'>>,
): Promise<TeamMember | null> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Mock: Updating team member (not persisted)');
    return {
      id,
      ...updates,
      name: updates.name || '',
      role: updates.role || '',
      bio: updates.bio || '',
      photo_url: updates.photo_url || '',
      order: updates.order || 0,
    };
  }

  try {
    const { data, error } = await client
      .from(TEAM_MEMBERS_TABLE)
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .maybeSingle();

    if (error) throw error;
    return data || null;
  } catch (error) {
    console.error('Error updating team member:', error);
    throw error;
  }
}

export async function deleteTeamMember(id: string): Promise<boolean> {
  const client = getSupabaseClient();

  if (!client || !isSupabaseConfigured()) {
    console.log('Mock: Deleting team member (not persisted)');
    return true;
  }

  try {
    const { error } = await client.from(TEAM_MEMBERS_TABLE).delete().eq('id', id);

    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error deleting team member:', error);
    throw error;
  }
}
