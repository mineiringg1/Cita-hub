import { Sprout, Target, Users } from 'lucide-react';

interface TeamMember {
  id: number;
  name: string;
  role: string;
  image: string;
}

const teamMembers: TeamMember[] = [
  {
    id: 1,
    name: "Ana Silva",
    role: "Coordenadora Geral",
    image: "https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop"
  },
  {
    id: 2,
    name: "Carlos Santos",
    role: "Especialista em Tecnologia",
    image: "https://images.pexels.com/photos/1181695/pexels-photo-1181695.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop"
  },
  {
    id: 3,
    name: "Marina Costa",
    role: "Pesquisadora de Sustentabilidade",
    image: "https://images.pexels.com/photos/1181691/pexels-photo-1181691.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop"
  }
];

export default function About() {
  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-[#2D5016] mb-4">Sobre o CITA Hub</h1>
          <div className="w-20 h-1 bg-gradient-to-r from-[#4A7C2C] to-[#A0A956]"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mb-16">
          <section className="lg:col-span-3">
            <div className="flex items-start gap-4 mb-12">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-16 w-16 rounded-full bg-[#4A7C2C]/10">
                  <Sprout className="h-8 w-8 text-[#4A7C2C]" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-3xl font-bold text-[#2D5016] mb-4">Quem Somos</h2>
                <p className="text-gray-700 text-lg leading-relaxed mb-4">
                  O CITA Hub é um grupo de estudos dinamicamente formado por alunos de Agronomia e Agronegócio da UNIPAC de Uberlândia. Somos uma comunidade acadêmica comprometida com a excelência, a inovação e o desenvolvimento prático de soluções para os desafios contemporâneos do agronegócio.
                </p>
                <p className="text-gray-700 text-lg leading-relaxed">
                  Com paixão pela agricultura moderna, nossos membros trazem perspectivas multidisciplinares, combinando conhecimento teórico com visão prática para transformar a forma como o campo opera atualmente.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 mb-12 bg-[#F5F9F0] p-8 rounded-lg">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-16 w-16 rounded-full bg-[#2D5016]/10">
                  <Target className="h-8 w-8 text-[#2D5016]" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-3xl font-bold text-[#2D5016] mb-4">Nosso Objetivo</h2>
                <p className="text-gray-700 text-lg leading-relaxed mb-4">
                  Ser a ponte conectando o conhecimento acadêmico de qualidade com as tecnologias de ponta desenvolvidas pelas empresas inovadoras e, fundamentalmente, com as necessidades reais dos produtores rurais da região.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
                  <div className="bg-white p-4 rounded-lg border border-[#4A7C2C]/20">
                    <p className="font-semibold text-[#2D5016] mb-2">Conectar</p>
                    <p className="text-sm text-gray-600">Academia, empresas e produtores em um único ecossistema</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg border border-[#4A7C2C]/20">
                    <p className="font-semibold text-[#2D5016] mb-2">Inovar</p>
                    <p className="text-sm text-gray-600">Desenvolvimento de soluções tecnológicas sustentáveis</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg border border-[#4A7C2C]/20">
                    <p className="font-semibold text-[#2D5016] mb-2">Impactar</p>
                    <p className="text-sm text-gray-600">Transformar a realidade agrícola com conhecimento prático</p>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>

        <section>
          <div className="flex items-center gap-4 mb-12">
            <div className="flex-shrink-0">
              <div className="flex items-center justify-center h-16 w-16 rounded-full bg-[#4A7C2C]/10">
                <Users className="h-8 w-8 text-[#4A7C2C]" />
              </div>
            </div>
            <div className="flex-1">
              <h2 className="text-3xl font-bold text-[#2D5016]">Nossa Equipe</h2>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {teamMembers.map((member) => (
              <div
                key={member.id}
                className="group bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 border border-gray-100"
              >
                <div className="relative overflow-hidden h-64">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#2D5016]/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>

                <div className="p-6">
                  <h3 className="text-xl font-bold text-[#2D5016] mb-2">{member.name}</h3>
                  <p className="text-[#4A7C2C] font-semibold text-sm mb-4">{member.role}</p>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    Apaixonado(a) por inovação agrícola e dedicado(a) a transformar o conhecimento em soluções práticas para o campo.
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-16 bg-gradient-to-r from-[#2D5016]/5 to-[#4A7C2C]/5 rounded-lg p-8 md:p-12">
          <h2 className="text-2xl font-bold text-[#2D5016] mb-4">Acreditamos que</h2>
          <p className="text-gray-700 text-lg leading-relaxed max-w-3xl">
            A agricultura é o coração da economia e da sustentabilidade global. Por isso, dedicamos nosso tempo e talento em buscar, estudar e disseminar conhecimento sobre tecnologias e práticas que potencializem a produtividade, a sustentabilidade e a qualidade de vida dos produtores rurais da região e além.
          </p>
        </section>
      </div>
    </div>
  );
}
