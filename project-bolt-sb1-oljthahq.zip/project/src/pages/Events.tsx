import { useEffect, useState } from 'react';
import { Calendar, MapPin, Users, Clock } from 'lucide-react';
import { fetchEvents, type Event } from '../services/api/events';
import EventSkeleton from '../components/EventSkeleton';

export default function Events() {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<'Todos' | 'Workshop' | 'Palestra' | 'Atividade'>('Todos');

  useEffect(() => {
    const loadEvents = async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await fetchEvents();
        setEvents(data);
      } catch (err) {
        setError('Erro ao carregar os eventos. Tente novamente mais tarde.');
        console.error('Error fetching events:', err);
      } finally {
        setLoading(false);
      }
    };

    loadEvents();
  }, []);

  const filteredEvents = filter === 'Todos' ? events : events.filter((e) => e.category === filter);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Workshop':
        return 'bg-purple-100 text-purple-700';
      case 'Palestra':
        return 'bg-blue-100 text-blue-700';
      case 'Atividade':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getCategoryGradient = (category: string) => {
    switch (category) {
      case 'Workshop':
        return 'from-purple-500 to-purple-600';
      case 'Palestra':
        return 'from-blue-500 to-blue-600';
      case 'Atividade':
        return 'from-green-500 to-green-600';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(`${dateString}T00:00:00`);
    return new Intl.DateTimeFormat('pt-BR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(date);
  };

  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(':');
    return `${hours}:${minutes}`;
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="relative h-80 sm:h-96 overflow-hidden rounded-lg shadow-lg mb-12">
        <img
          src="https://images.pexels.com/photos/3632561/pexels-photo-3632561.jpeg?auto=compress&cs=tinysrgb&w=1200"
          alt="Eventos CITA Hub"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-600/80 to-teal-600/70 flex items-center justify-center">
          <div className="text-center text-white px-4">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Calendar size={40} />
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-2">
              Eventos e Agenda
            </h1>
            <p className="text-lg sm:text-xl opacity-90">
              Workshops, palestras e atividades do CITA Hub
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Próximos Eventos</h2>

          <div className="flex flex-wrap gap-3 mb-8">
            {(['Todos', 'Workshop', 'Palestra', 'Atividade'] as const).map((category) => (
              <button
                key={category}
                onClick={() => setFilter(category)}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
                  filter === category
                    ? 'bg-emerald-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {error && (
            <div className="mb-8 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-700">{error}</p>
            </div>
          )}

          {loading ? (
            <div className="space-y-6">
              {Array.from({ length: 3 }).map((_, i) => (
                <EventSkeleton key={i} />
              ))}
            </div>
          ) : filteredEvents.length > 0 ? (
            <div className="space-y-6">
              {filteredEvents.map((event) => (
                <div
                  key={event.id}
                  className="group flex flex-col md:flex-row h-full bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 border border-gray-100"
                >
                  <div className="relative overflow-hidden h-48 md:h-auto md:w-64 flex-shrink-0">
                    <img
                      src={event.image}
                      alt={event.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-4 left-4">
                      <span
                        className={`px-3 py-1 ${getCategoryColor(event.category)} text-xs font-semibold rounded-full`}
                      >
                        {event.category}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-col flex-1 p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-emerald-600 transition-colors duration-300">
                      {event.title}
                    </h3>

                    <p className="text-gray-600 text-sm mb-6 flex-1">
                      {event.description}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6 pb-6 border-b border-gray-100">
                      <div className="flex items-center text-gray-600 text-sm">
                        <Calendar size={16} className="mr-2 text-emerald-600" />
                        <span>{formatDate(event.date)}</span>
                      </div>

                      <div className="flex items-center text-gray-600 text-sm">
                        <Clock size={16} className="mr-2 text-emerald-600" />
                        <span>{formatTime(event.time)}</span>
                      </div>

                      <div className="flex items-center text-gray-600 text-sm sm:col-span-2">
                        <MapPin size={16} className="mr-2 text-emerald-600" />
                        <span>{event.location}</span>
                      </div>

                      <div className="flex items-center text-gray-600 text-sm">
                        <Users size={16} className="mr-2 text-emerald-600" />
                        <span>
                          {event.registered}/{event.capacity} inscritos
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="w-full bg-gray-200 rounded-full h-2 mr-4">
                        <div
                          className={`bg-gradient-to-r ${getCategoryGradient(event.category)} h-2 rounded-full`}
                          style={{ width: `${(event.registered / event.capacity) * 100}%` }}
                        ></div>
                      </div>
                      <button className="px-6 py-2 bg-gradient-to-r from-emerald-600 to-emerald-700 text-white font-medium rounded-lg hover:shadow-lg hover:from-emerald-700 hover:to-emerald-800 transition-all duration-300 whitespace-nowrap">
                        Inscrever-se
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Calendar size={48} className="mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500 text-lg">Nenhum evento encontrado nesta categoria.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
