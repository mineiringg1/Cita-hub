import { useEffect, useState } from 'react';
import { Plus, Trash2, CreditCard as Edit2, Check, X } from 'lucide-react';
import { getBoletins, addBoletim, deleteBoletim, type Boletim } from '../services/db';

export default function Admin() {
  const [boletins, setBoletins] = useState<Boletim[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    summary: '',
    category: 'Tecnologia',
    image: '',
    date: new Date().toISOString().split('T')[0],
    content: '',
  });

  useEffect(() => {
    loadBoletins();
  }, []);

  const loadBoletins = async () => {
    try {
      setLoading(true);
      const data = await getBoletins();
      setBoletins(data);
    } catch (error) {
      console.error('Error loading boletins:', error);
      setMessage({ type: 'error', text: 'Erro ao carregar boletins' });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title || !formData.summary || !formData.category || !formData.date) {
      setMessage({ type: 'error', text: 'Preencha todos os campos obrigatórios' });
      return;
    }

    try {
      setSaving(true);
      await addBoletim({
        title: formData.title,
        summary: formData.summary,
        category: formData.category,
        image: formData.image || 'https://images.pexels.com/photos/3944441/pexels-photo-3944441.jpeg?auto=compress&cs=tinysrgb&w=600',
        date: formData.date,
        content: formData.content,
      });

      setMessage({ type: 'success', text: 'Boletim criado com sucesso!' });
      setFormData({
        title: '',
        summary: '',
        category: 'Tecnologia',
        image: '',
        date: new Date().toISOString().split('T')[0],
        content: '',
      });
      setShowForm(false);

      await loadBoletins();

      setTimeout(() => {
        setMessage(null);
      }, 3000);
    } catch (error) {
      console.error('Error creating boletim:', error);
      setMessage({ type: 'error', text: 'Erro ao criar boletim' });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir este boletim?')) return;

    try {
      setSaving(true);
      await deleteBoletim(id);
      setMessage({ type: 'success', text: 'Boletim excluído com sucesso!' });
      await loadBoletins();

      setTimeout(() => {
        setMessage(null);
      }, 3000);
    } catch (error) {
      console.error('Error deleting boletim:', error);
      setMessage({ type: 'error', text: 'Erro ao excluir boletim' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Painel Administrativo</h1>
          <p className="text-gray-600">Gerencie boletins, eventos e conteúdo do CITA Hub</p>
        </div>

        {message && (
          <div
            className={`mb-6 p-4 rounded-lg flex items-center gap-3 ${
              message.type === 'success'
                ? 'bg-green-50 border border-green-200 text-green-700'
                : 'bg-red-50 border border-red-200 text-red-700'
            }`}
          >
            {message.type === 'success' ? (
              <Check size={20} />
            ) : (
              <X size={20} />
            )}
            {message.text}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-3xl font-bold text-[#2D5016]">{boletins.length}</div>
            <p className="text-gray-600 text-sm mt-1">Boletins Publicados</p>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-3xl font-bold text-blue-600">0</div>
            <p className="text-gray-600 text-sm mt-1">Eventos Criados</p>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-3xl font-bold text-purple-600">0</div>
            <p className="text-gray-600 text-sm mt-1">Usuários Ativos</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow mb-8">
          <div className="border-b border-gray-200 p-6 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-900">Boletins</h2>
            <button
              onClick={() => setShowForm(!showForm)}
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#2D5016] text-white rounded-lg hover:bg-[#1f3810] transition-colors"
            >
              <Plus size={20} />
              Novo Boletim
            </button>
          </div>

          {showForm && (
            <div className="border-b border-gray-200 p-6 bg-gray-50">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input
                    type="text"
                    name="title"
                    placeholder="Título"
                    value={formData.title}
                    onChange={handleInputChange}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#2D5016]"
                    required
                  />
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#2D5016]"
                  >
                    <option>Tecnologia</option>
                    <option>Sustentabilidade</option>
                    <option>Inovação</option>
                    <option>Inteligência Artificial</option>
                  </select>
                </div>

                <textarea
                  name="summary"
                  placeholder="Resumo"
                  value={formData.summary}
                  onChange={handleInputChange}
                  rows={2}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#2D5016]"
                  required
                />

                <textarea
                  name="content"
                  placeholder="Conteúdo completo (opcional)"
                  value={formData.content}
                  onChange={handleInputChange}
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#2D5016]"
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input
                    type="url"
                    name="image"
                    placeholder="URL da imagem"
                    value={formData.image}
                    onChange={handleInputChange}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#2D5016]"
                  />
                  <input
                    type="date"
                    name="date"
                    value={formData.date}
                    onChange={handleInputChange}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#2D5016]"
                    required
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    type="submit"
                    disabled={saving}
                    className="px-6 py-2 bg-[#2D5016] text-white rounded-lg hover:bg-[#1f3810] transition-colors disabled:opacity-50 flex items-center gap-2"
                  >
                    {saving && <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>}
                    {saving ? 'Salvando...' : 'Salvar'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="px-6 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors"
                  >
                    Cancelar
                  </button>
                </div>
              </form>
            </div>
          )}

          {loading ? (
            <div className="p-6 text-center text-gray-500">Carregando boletins...</div>
          ) : boletins.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Título</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Categoria</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Data</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {boletins.map((boletim) => (
                    <tr key={boletim.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm text-gray-900">{boletim.title}</td>
                      <td className="px-6 py-4 text-sm">
                        <span className="px-3 py-1 bg-[#4A7C2C] text-white text-xs rounded-full">
                          {boletim.category}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">{boletim.date}</td>
                      <td className="px-6 py-4 text-sm flex gap-2">
                        <button className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                          <Edit2 size={16} />
                        </button>
                        <button
                          onClick={() => handleDelete(boletim.id)}
                          disabled={saving}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50"
                        >
                          <Trash2 size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-6 text-center text-gray-500">Nenhum boletim criado ainda</div>
          )}
        </div>
      </div>
    </div>
  );
}
