import { useEffect, useState } from 'react';
import { BookOpen, Folder } from 'lucide-react';
import { fetchLibraryAxes, type Axis } from '../services/api/library';
import AxisSkeleton from '../components/AxisSkeleton';

export default function Library() {
  const [axes, setAxes] = useState<Axis[]>([]);
  const [selectedAxis, setSelectedAxis] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadAxes = async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await fetchLibraryAxes();
        setAxes(data);
        if (data.length > 0) {
          setSelectedAxis(data[0].id);
        }
      } catch (err) {
        setError('Erro ao carregar a biblioteca. Tente novamente mais tarde.');
        console.error('Error fetching library:', err);
      } finally {
        setLoading(false);
      }
    };

    loadAxes();
  }, []);

  const currentAxis = axes.find((axis) => axis.id === selectedAxis);

  return (
    <div className="min-h-screen bg-white">
      <div className="relative h-80 sm:h-96 overflow-hidden rounded-lg shadow-lg mb-12">
        <img
          src="https://images.pexels.com/photos/3944441/pexels-photo-3944441.jpeg?auto=compress&cs=tinysrgb&w=1200"
          alt="Biblioteca CITA Hub"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/80 to-cyan-600/70 flex items-center justify-center">
          <div className="text-center text-white px-4">
            <div className="flex items-center justify-center gap-3 mb-4">
              <BookOpen size={40} />
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-2">
              Biblioteca
            </h1>
            <p className="text-lg sm:text-xl opacity-90">
              Explore conteúdos organizados por eixos temáticos
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Eixos Temáticos</h2>

          {error && (
            <div className="mb-8 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-700">{error}</p>
            </div>
          )}

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              {Array.from({ length: 3 }).map((_, i) => (
                <AxisSkeleton key={i} />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              {axes.map((axis) => (
                <button
                  key={axis.id}
                  onClick={() => setSelectedAxis(axis.id)}
                  className={`group relative overflow-hidden rounded-lg shadow-md transition-all duration-300 h-48 cursor-pointer ${
                    selectedAxis === axis.id ? 'ring-4 ring-offset-2 ring-blue-500' : 'hover:shadow-xl'
                  }`}
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${axis.color} opacity-80`}></div>
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-white">
                    <Folder size={40} className="mb-3 opacity-90 group-hover:scale-110 transition-transform" />
                    <h3 className="text-2xl font-bold text-center mb-2">{axis.name}</h3>
                    <p className="text-sm opacity-90 text-center">{axis.items.length} recursos</p>
                  </div>
                </button>
              ))}
            </div>
          )}

          {currentAxis && (
            <div className="space-y-6">
              <div className="border-b-2 border-gray-200 pb-6">
                <h3 className={`text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r ${currentAxis.color} mb-2`}>
                  {currentAxis.name}
                </h3>
                <p className="text-gray-600">{currentAxis.description}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {currentAxis.items.map((item) => (
                  <div
                    key={item.id}
                    className="group flex flex-col h-full bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 border border-gray-100"
                  >
                    <div className="relative overflow-hidden h-40">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300"></div>
                    </div>

                    <div className="flex flex-col flex-1 p-5">
                      <h4 className="text-lg font-bold text-gray-900 mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors duration-300">
                        {item.title}
                      </h4>

                      <p className="text-gray-600 text-sm mb-4 flex-1 line-clamp-2">
                        {item.description}
                      </p>

                      <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                        <span className="text-xs font-semibold text-blue-600">
                          {item.resources} recursos
                        </span>
                        <button className="px-3 py-2 bg-blue-50 text-blue-600 rounded-lg text-xs font-medium hover:bg-blue-100 transition-colors">
                          Acessar
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
