import { useEffect, useState } from 'react';
import { ArrowRight, Calendar } from 'lucide-react';
import { fetchArticles, type Article } from '../services/api/articles';
import ArticleSkeleton from '../components/ArticleSkeleton';

export default function Home() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadArticles = async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await fetchArticles();
        setArticles(data);
      } catch (err) {
        setError('Erro ao carregar os boletins. Tente novamente mais tarde.');
        console.error('Error fetching articles:', err);
      } finally {
        setLoading(false);
      }
    };

    loadArticles();
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <div className="relative h-96 sm:h-[28rem] md:h-[32rem] overflow-hidden rounded-lg shadow-lg mb-12">
        <img
          src="https://images.pexels.com/photos/5632399/pexels-photo-5632399.jpeg?auto=compress&cs=tinysrgb&w=1200"
          alt="Banner CITA Hub"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#2D5016]/80 to-[#4A7C2C]/70 flex items-center justify-center">
          <div className="text-center text-white px-4">
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              Inovação no Campo
            </h1>
            <p className="text-lg sm:text-xl md:text-2xl opacity-90">
              Descubra as tecnologias e práticas que estão transformando a agricultura
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-[#2D5016] mb-2">Boletins Recentes</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-[#4A7C2C] to-[#A0A956]"></div>
        </div>

        {error && (
          <div className="mb-8 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-12">
          {loading ? (
            <>
              {Array.from({ length: 3 }).map((_, i) => (
                <ArticleSkeleton key={i} />
              ))}
            </>
          ) : (
            articles.map((article) => (
              <div
                key={article.id}
                className="group flex flex-col h-full bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 border border-gray-100"
              >
                <div className="relative overflow-hidden h-48">
                  <img
                    src={article.image}
                    alt={article.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300"></div>
                  <div className="absolute top-4 right-4">
                    <span className="px-3 py-1 bg-[#4A7C2C] text-white text-xs font-semibold rounded-full">
                      {article.category}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col flex-1 p-6">
                  <h3 className="text-xl font-bold text-[#2D5016] mb-3 line-clamp-2 group-hover:text-[#4A7C2C] transition-colors duration-300">
                    {article.title}
                  </h3>

                  <p className="text-gray-600 text-sm mb-4 flex-1 line-clamp-3">
                    {article.summary}
                  </p>

                  <div className="flex items-center text-gray-500 text-xs mb-6 pt-4 border-t border-gray-100">
                    <Calendar size={16} className="mr-2" />
                    <span>{article.date}</span>
                  </div>

                  <button className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-[#4A7C2C] to-[#3A5F1F] text-white font-medium rounded-lg hover:shadow-lg hover:from-[#3A5F1F] hover:to-[#2D5016] transition-all duration-300 group/btn">
                    <span>Ler Mais</span>
                    <ArrowRight size={18} className="group-hover/btn:translate-x-1 transition-transform duration-300" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
