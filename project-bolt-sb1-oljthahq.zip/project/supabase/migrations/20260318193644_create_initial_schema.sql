/*
  # Create Initial Schema for CITA Hub CMS

  1. New Tables
    - `boletins` - Articles/newsletters
      - `id` (uuid, primary key)
      - `title` (text)
      - `summary` (text)
      - `content` (text)
      - `category` (text)
      - `image` (text URL)
      - `date` (date)
      - `created_at`, `updated_at` (timestamps)
    
    - `eventos` - Events
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `date` (date), `time` (time)
      - `location` (text)
      - `category` (text)
      - `image` (text URL)
      - `capacity` (integer)
      - `registered` (integer)
      - `created_at`, `updated_at` (timestamps)
    
    - `site_settings` - Global site configuration
      - `id` (uuid, primary key)
      - `logo_url` (text)
      - `mission` (text)
      - `vision` (text)
      - `values` (text)
      - `contact_email` (text)
      - `phone` (text)
      - `address` (text)
      - `updated_at` (timestamp)
    
    - `team_members` - Team members for About page
      - `id` (uuid, primary key)
      - `name` (text)
      - `role` (text)
      - `bio` (text)
      - `photo_url` (text)
      - `order` (integer)
      - `created_at`, `updated_at` (timestamps)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users (admin) and public access (site_settings, team_members for SELECT)
*/

CREATE TABLE IF NOT EXISTS boletins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  summary text NOT NULL,
  content text NOT NULL,
  category text NOT NULL,
  image text,
  date date NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS eventos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  date date NOT NULL,
  time time NOT NULL,
  location text NOT NULL,
  category text NOT NULL,
  image text,
  capacity integer NOT NULL DEFAULT 0,
  registered integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS site_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  logo_url text,
  mission text,
  vision text,
  values text,
  contact_email text,
  phone text,
  address text,
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS team_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  role text NOT NULL,
  bio text,
  photo_url text,
  "order" integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE boletins ENABLE ROW LEVEL SECURITY;
ALTER TABLE eventos ENABLE ROW LEVEL SECURITY;
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE team_members ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Boletins readable by authenticated users"
  ON boletins FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Boletins writable by authenticated users"
  ON boletins FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Boletins updatable by authenticated users"
  ON boletins FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Boletins deletable by authenticated users"
  ON boletins FOR DELETE
  TO authenticated
  USING (true);

CREATE POLICY "Eventos readable by authenticated users"
  ON eventos FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Eventos writable by authenticated users"
  ON eventos FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Eventos updatable by authenticated users"
  ON eventos FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Eventos deletable by authenticated users"
  ON eventos FOR DELETE
  TO authenticated
  USING (true);

CREATE POLICY "Site settings readable by everyone"
  ON site_settings FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Site settings updatable by authenticated users"
  ON site_settings FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Site settings insertable by authenticated users"
  ON site_settings FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Team members readable by everyone"
  ON team_members FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Team members writable by authenticated users"
  ON team_members FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Team members updatable by authenticated users"
  ON team_members FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members deletable by authenticated users"
  ON team_members FOR DELETE
  TO authenticated
  USING (true);
